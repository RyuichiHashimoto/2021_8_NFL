"""
helmet_assignment.

Helper code for the 2021 NFL Helmet Assignment Competition
"""

__version__ = "0.1.0"
__author__ = 'Rob Mulla'
